#! /usr/bin/python3.13
#
# Argument Clinic
# Copyright 2012-2013 by Larry Hastings.
# Licensed to the PSF under a contributor agreement.
#
from libclinic.cli import main


if __name__ == "__main__":
    main()
