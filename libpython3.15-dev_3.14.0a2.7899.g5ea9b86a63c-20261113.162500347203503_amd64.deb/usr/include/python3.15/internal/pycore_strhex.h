#ifndef Py_INTERNAL_STRHEX_H
#define Py_INTERNAL_STRHEX_H
#ifdef __cplusplus
extern "C" {
#endif

#ifndef Py_BUILD_CORE
#  error "this header requires Py_BUILD_CORE define"
#endif

// Returns a str() containing the hex representation of argbuf.
// Export for '_hashlib' shared extension.
PyAPI_FUNC(PyObject *) _Py_strhex(const char *argbuf, Py_ssize_t arglen);

// Returns a bytes() containing the ASCII hex representation of argbuf.
extern PyObject *_Py_strhex_bytes(const char *argbuf, Py_ssize_t arglen);

// These variants include support for a separator between every N bytes:
extern PyObject *_Py_strhex_with_sep(
    const char *argbuf,
    Py_ssize_t arglen,
    PyObject *sep,
    Py_ssize_t bytes_per_group);

// Export for 'binascii' shared extension
PyAPI_FUNC(PyObject *) _Py_strhex_bytes_with_sep(
    const char *argbuf,
    Py_ssize_t arglen,
    PyObject *sep,
    Py_ssize_t bytes_per_group);

#ifdef __cplusplus
}
#endif
#endif /* !Py_INTERNAL_STRHEX_H */
